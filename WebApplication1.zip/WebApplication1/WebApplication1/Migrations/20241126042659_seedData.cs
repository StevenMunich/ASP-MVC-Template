﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace WebApplication1.Migrations
{
    /// <inheritdoc />
    public partial class seedData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "DiaryEntries",
                columns: new[] { "Id", "Content", "Created", "Title" },
                values: new object[,]
                {
                    { 1, "With joe", new DateTime(2024, 11, 25, 20, 26, 58, 546, DateTimeKind.Local).AddTicks(6071), "WentHiking" },
                    { 2, "With Mother", new DateTime(2024, 11, 25, 20, 26, 58, 546, DateTimeKind.Local).AddTicks(6810), "Went Shopping" },
                    { 3, "With Joe!", new DateTime(2024, 11, 25, 20, 26, 58, 546, DateTimeKind.Local).AddTicks(6818), "Went Swimming" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "DiaryEntries",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "DiaryEntries",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "DiaryEntries",
                keyColumn: "Id",
                keyValue: 3);
        }
    }
}
