﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Data
{
    public class ApplicationDbContext : DbContext
    {

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { 
  
        }

        public DbSet<DiaryEntry> DiaryEntries { get; set; } //step 2 part from EntityFrameworkCore
                                                            
        //Tools ->Nuget Package Manager -> Console: add-migration AddDiaryEntryTable                                                
        //Migration is instruction to database
                                                            
        // update-database

        //Four steps to add a table
        // 1. Create a Model Class
        // 2. Add DB Set
        // 3. add-migration AddDiaryEntryTable
        // 4. update-database
     
        } //end class
    } //end namespace

