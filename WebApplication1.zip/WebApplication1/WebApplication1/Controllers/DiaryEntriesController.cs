﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class DiaryEntriesController : Controller
    {
        private readonly ApplicationDbContext _db;

        public DiaryEntriesController(ApplicationDbContext db) //DEPENDANCY INJECTION- ApplicationDbContext is injected.
        {
            _db = db; //only possible because we REGISTERED dbContext. Not creating an object
                      //in Program.cs builer.Services.AddDbContext<ApplicationDbContext>(options...
                      //_db can now be used throughout the program
        }
        public IActionResult Index()
        {
            //Putting the List of Entries into an object.
            List<DiaryEntry> objDiaryEntryList = _db.DiaryEntries.ToList(); //DiaryEntries is Table
            //Then passing it to the View
            return View(objDiaryEntryList);
        }
        public IActionResult Create() //MUST MATCH VIEW NAME
        {
            return View(); //new DiaryEntry() inside View
        }


        //Adds to Database
        [HttpPost]
        public IActionResult Create(DiaryEntry obj)  //MUST MATCH VIEW NAME
        {
            //This is server-side validation
            if(obj != null && obj.Content.Length < 10)
            {
                ModelState.AddModelError("Content", "Content must be over 10 characters");
            }
            //more server-side validation.
            //If true add to DB and redirect to index view
            if (ModelState.IsValid)
            {
                _db.DiaryEntries.Add(obj); //adds obj passed from view
                _db.SaveChanges(); //Actually saves it

                return RedirectToAction("Index"); //returns to Index in Current Controller.
                                                  //Can add 2nd parameter to go to another controller.
            }
            return View(obj); //refreshes page & displays server-side error message

        } //End Post Method

        //This is a GET request by default. you can add [HttpGet]


        public IActionResult Edit(int? id)
        { //Error IF YOU DO NOT MAKE THIS PUBLIC!!!!! Lol ;)

            if (id == null || id == 0)
            {
                return NotFound();
            }

            DiaryEntry? diaryEntry = _db.DiaryEntries.Find(id);

            if (diaryEntry != null)
            {
                //_db.DiaryEntries.Remove(diaryEntry);
                //_db.SaveChanges();
            }
            if (diaryEntry == null)
            {
                return NotFound();
            }

            return View(diaryEntry);
        }//end Edit

        [HttpPost]
        public IActionResult Edit(DiaryEntry obj)  //MUST MATCH VIEW NAME
        {
            //This is server-side validation
            if (obj != null && obj.Content.Length < 10)
            {
                ModelState.AddModelError("Content", "Content must be over 10 characters");
            }
            if (ModelState.IsValid)
            {
                _db.DiaryEntries.Update(obj); //updates obj passed from view
                _db.SaveChanges(); //Actually saves it

                return RedirectToAction("Index"); //returns to Index in Current Controller.
                                                  //Can add 2nd parameter to go to another controller.
            }
            
            return View(obj); //refreshes page & displays server-side error message

        } //End Post Method


        public IActionResult Delete(int? id)
        { //Error IF YOU DO NOT MAKE THIS PUBLIC!!!!! Lol ;)

            

            if (id == null || id == 0)
            {
                return NotFound();
            }


            DiaryEntry? diaryEntry = _db.DiaryEntries.Find(id);

            if (diaryEntry != null)
            {
                //_db.DiaryEntries.Remove(diaryEntry);
                //_db.SaveChanges();
            }
            if (diaryEntry == null)
            {
                return NotFound();
            }

            return View();
        }//end Delete
    }
}
