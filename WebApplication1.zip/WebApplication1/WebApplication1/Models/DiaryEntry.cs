﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class DiaryEntry
    {
        [Key] //Annotations
        public int Id { set; get; }

        [Required(ErrorMessage = "Please enter a Title")] //This is client-side validation
        [StringLength(100, MinimumLength = 3, ErrorMessage ="Title must be between 3 and 100 in length")]
        public string Title { set; get; } = string.Empty;//add ? after Type for nullable. or initialize it
        [Required]
        public string Content { set; get; } = string.Empty;
        [Required]
        public DateTime Created { set; get; } = DateTime.Now;
    }
}
