THIS IS NOT A CODING PROJECT!
THIS IS NOT A CODING PROJECT!
This project is a template and analysis for MVC arhicecture

This is a personal project that I am sharing for myself in the future and anyone else interested in learning
about back-end web technology

Required software:
1. MS Sql Server
2. SSMS(SQL server managemant studio)
The IDE used is Visual Studio and there are 3 addons that must be installed mentioned in the overview.

Pre-requisite knowledge
1. Front-end webdev(html,css,javascript)
2. Basics of databases
3. Object-oriented programming
4. Dynamic programming
5. Networking